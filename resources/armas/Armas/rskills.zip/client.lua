local SignPainterHouseScript22 = dxCreateFont("house-script.ttf", 22)
local screenW,screenH = guiGetScreenSize()
local resW,resH = 1280,720
local sW,sH =  (screenW/resW), (screenH/resH)


    function drawWeaponSkills()
	--[[
	    --# Vehicle Skills
        dxDrawText("Vehicle Skills", 111, 323, 326, 362, tocolor(255, 255, 255, 255), 1.00, SignPainterHouseScript22, "left", "center", false, false, true, false, false)		
		dxDrawRectangle(111, 362, 345, 305, tocolor(0, 0, 0, 80), true)

		local Skill_Driving = getPedStat ( localPlayer, 160 )		
        dxDrawText("Driving", 121, 403, 252, 417, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
        dxDrawText(Skill_Driving.."/1000", 251, 403, 446, 417, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)		
	    ]]
		
		--# Weapon Skills
        dxDrawRectangle(467, 362, 345, 305, tocolor(0, 0, 0, 80), true)
        dxDrawText("Weapon Skills", 466, 323, 681, 362, tocolor(255, 255, 255, 255), 1.00, SignPainterHouseScript22, "left", "center", false, false, true, false, false)

		local Skill_AK47 = getPedStat ( localPlayer, 77 )
        dxDrawText("AK-47", 476, 403, 607, 417, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)		
		dxDrawRectangle(607, 403, 194, 14, tocolor(0, 0, 0, 80), true)
		dxDrawRectangle(607, 403, 194/1000*Skill_AK47, 14, tocolor(0, 255, 112, 255), true)		
        dxDrawText(Skill_AK47.."/1000", 606, 403, 801, 417, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
		
		local Skill_Desert_Eagle = getPedStat ( localPlayer, 71 )		
		dxDrawText("Desert Eagle", 476, 427, 607, 441, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
        dxDrawRectangle(607, 427, 194, 14, tocolor(0, 0, 0, 80), true)
		dxDrawRectangle(607, 427, 194/1000*Skill_Desert_Eagle, 14, tocolor(0, 255, 112, 255), true)	
        dxDrawText(Skill_Desert_Eagle.."/1000", 606, 427, 801, 441, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
		
		local Skill_M4 = getPedStat ( localPlayer, 78 )
		dxDrawText("M4", 477, 451, 608, 465, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
        dxDrawRectangle(608, 451, 194, 14, tocolor(0, 0, 0, 80), true)
        dxDrawRectangle(608, 451, 194/1000*Skill_M4, 14, tocolor(0, 255, 112, 255), true)		
        dxDrawText(Skill_M4.."/1000", 608, 451, 801, 465, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
		
		local Skill_MP5 = getPedStat ( localPlayer, 76 )
		dxDrawText("MP5", 477, 475, 608, 489, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
        dxDrawRectangle(608, 475, 194, 14, tocolor(0, 0, 0, 80), true)
        dxDrawRectangle(608, 475, 194/1000*Skill_MP5, 14, tocolor(0, 255, 112, 255), true)		
        dxDrawText(Skill_MP5.."/1000", 608, 475, 801, 489, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
		
		local Skill_Pistol = getPedStat ( localPlayer, 69 )		
		dxDrawText("Pistol", 477, 499, 608, 513, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
        dxDrawRectangle(608, 499, 194, 14, tocolor(0, 0, 0, 80), true)
        dxDrawRectangle(608, 499, 194/1000*Skill_Pistol, 14, tocolor(0, 255, 112, 255), true)        
        dxDrawText(Skill_Pistol.."/1000", 608, 499, 801, 513, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
		
		local Skill_Sawnoff_Shotgun = getPedStat ( localPlayer, 73 )			
		dxDrawText("Sawnoff Shotgun", 477, 523, 608, 537, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
        dxDrawRectangle(608, 523, 194, 14, tocolor(0, 0, 0, 80), true)
        dxDrawRectangle(608, 523, 194/1000*Skill_Sawnoff_Shotgun, 14, tocolor(0, 255, 112, 255), true)		
        dxDrawText(Skill_Sawnoff_Shotgun.."/1000", 608, 523, 801, 537, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
		
		local Skill_Shotgun = getPedStat ( localPlayer, 72 )		
        dxDrawText("Shotgun", 477, 547, 608, 561, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
        dxDrawRectangle(608, 547, 194, 14, tocolor(0, 0, 0, 80), true)
        dxDrawRectangle(608, 547, 194/1000*Skill_Shotgun, 14, tocolor(0, 255, 112, 255), true)		
        dxDrawText(Skill_Shotgun.."/1000", 608, 547, 801, 561, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
		
		local Skill_Silenced_Pistol = getPedStat ( localPlayer, 70 )		
        dxDrawText("Silenced Pistol", 477, 571, 608, 585, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
        dxDrawRectangle(607, 571, 194, 14, tocolor(0, 0, 0, 80), true)
        dxDrawRectangle(607, 571, 194/1000*Skill_Silenced_Pistol, 14, tocolor(0, 255, 112, 255), true)
        dxDrawText(Skill_Silenced_Pistol.."/1000", 608, 571, 801, 585, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
		
		local Skill_Sniper_Rifle = getPedStat ( localPlayer, 79 )		
        dxDrawText("Sniper Rifle", 477, 595, 608, 609, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
        dxDrawRectangle(608, 595, 194, 14, tocolor(0, 0, 0, 80), true)
        dxDrawRectangle(608, 595, 194/1000*Skill_Sniper_Rifle, 14, tocolor(0, 255, 112, 255), true)		
        dxDrawText(Skill_Sniper_Rifle.."/1000", 607, 595, 801, 609, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
		
		local Skill_SPAZ12 = getPedStat ( localPlayer, 74 )        
		dxDrawText("SPAZ-12", 477, 619, 608, 633, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
        dxDrawRectangle(608, 619, 194, 14, tocolor(0, 0, 0, 80), true)
        dxDrawRectangle(608, 619, 194/1000*Skill_SPAZ12, 14, tocolor(0, 255, 112, 255), true)        
        dxDrawText(Skill_SPAZ12.."/1000", 608, 619, 801, 633, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
		
		local Skill_Uzi = getPedStat ( localPlayer, 75 )        		
		dxDrawText("Uzi", 477, 643, 608, 657, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)
        dxDrawRectangle(608, 643, 194, 14, tocolor(0, 0, 0, 80), true)        
		dxDrawRectangle(608, 643, 194/1000*Skill_Uzi, 14, tocolor(0, 255, 112, 255), true)
        dxDrawText(Skill_Uzi.."/1000", 608, 643, 801, 657, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)		
        --[[
		--# Player Skills
        dxDrawText("Player Skills", 822, 323, 1037, 362, tocolor(255, 255, 255, 255), 1.00, SignPainterHouseScript22, "left", "center", false, false, true, false, false)		
        dxDrawRectangle(822, 362, 345, 305, tocolor(0, 0, 0, 80), true)

		local testSkill = getPedStat ( localPlayer, 170 )
        dxDrawText("Test Skill     "..testSkill, 832, 403, 963, 417, tocolor(255, 255, 255, 255), 1.00, "default-bold", "center", "center", false, false, true, false, false)		
	    --]]
	end

bindKey("Z", "down",
    function()	
        addEventHandler("onClientRender", root, drawWeaponSkills)
	end);
bindKey("Z", "up",
    function()	
        removeEventHandler("onClientRender", root, drawWeaponSkills)
	end);	